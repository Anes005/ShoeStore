export const  CATEGORIES_ENUM = [
  "Electronics",
  "Clothes",
  "Shoes",
  "Accessories",
  "Books",
  "Beauty",
  "Sports",
  "Home",
  "Kitchen",
  "Toys",
  "Food",
  "Other",
];
