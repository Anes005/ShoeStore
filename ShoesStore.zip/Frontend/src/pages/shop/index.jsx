import ProductsGrid from "../../features/shop/components/ProductsGrid";

function Shop(){
    return(
        <ProductsGrid/>
    )
}
export default Shop