function Footer() {
    return (
        <footer className="px-24 py-10 bg-black font-bold text-white">
      Ⓒ Copyright, All rights reserved to Anes Masmoudi
      </footer>
    )
}
export default Footer